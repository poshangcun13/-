# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 08:56:29 2024

@author: lenovo
"""
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 07:52:36 2024

@author: lenovo
"""
"""
Created on Mon May 13 19:21:09 2024

@author: lenovo
"""
import torch
import math
import copy
from torch import nn, Tensor
import torchvision.models
from torch.nn import functional as F
from matplotlib import pyplot as plt
from tqdm import tqdm
from torch import nn
from torch.utils.data import DataLoader
from torchvision.transforms import transforms
from functools import partial
from collections import OrderedDict
from typing import Optional, Callable
def _make_divisible(ch, divisor=8, min_ch=None):

    if min_ch is None:
        min_ch = divisor
    new_ch = max(min_ch, int(ch + divisor / 2) // divisor * divisor)
    # Make sure that round down does not go down by more than 10%.
    if new_ch < 0.9 * ch:
        new_ch += divisor
    return new_ch


def drop_path(x, drop_prob: float = 0., training: bool = False):

    if drop_prob == 0. or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # work with diff dim tensors, not just 2D ConvNets
    random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
    random_tensor.floor_()  # binarize
    output = x.div(keep_prob) * random_tensor
    return output


class DropPath(nn.Module):

    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path(x, self.drop_prob, self.training)


class ConvBNActivation(nn.Sequential):
    def __init__(self,
                 in_planes: int,
                 out_planes: int,
                 kernel_size: int = 3,
                 stride: int = 1,
                 groups: int = 1,
                 norm_layer = None,
                 activation_layer= None):
        padding = (kernel_size - 1) // 2
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        if activation_layer is None:
            activation_layer = nn.SiLU  # alias Swish  (torch>=1.7)

        super(ConvBNActivation, self).__init__(nn.Conv2d(in_channels=in_planes,
                                                         out_channels=out_planes,
                                                         kernel_size=kernel_size,
                                                         stride=stride,
                                                         padding=padding,
                                                         groups=groups,
                                                         bias=False),
                                               norm_layer(out_planes),
                                               activation_layer())


class SqueezeExcitation(nn.Module):
    def __init__(self,
                 input_c: int,   # block input channel
                 expand_c: int,  # block expand channel
                 squeeze_factor: int = 4):
        super(SqueezeExcitation, self).__init__()
        squeeze_c = input_c // squeeze_factor
        self.fc1 = nn.Conv2d(expand_c, squeeze_c, 1)
        self.ac1 = nn.SiLU()  # alias Swish
        self.fc2 = nn.Conv2d(squeeze_c, expand_c, 1)
        self.ac2 = nn.Sigmoid()

    def forward(self, x):
        scale = F.adaptive_avg_pool2d(x, output_size=(1, 1))
        scale = self.fc1(scale)
        scale = self.ac1(scale)
        scale = self.fc2(scale)
        scale = self.ac2(scale)
        return scale * x


class InvertedResidualConfig:
    # kernel_size, in_channel, out_channel, exp_ratio, strides, use_SE, drop_connect_rate
    def __init__(self,
                 kernel: int,          # 3 or 5
                 input_c: int,
                 out_c: int,
                 expanded_ratio: int,  # 1 or 6
                 stride: int,          # 1 or 2
                 use_se: bool,         # True
                 drop_rate: float,
                 index: str,           # 1a, 2a, 2b, ...
                 width_coefficient: float):
        self.input_c = self.adjust_channels(input_c, width_coefficient)
        self.kernel = kernel
        self.expanded_c = self.input_c * expanded_ratio
        self.out_c = self.adjust_channels(out_c, width_coefficient)
        self.use_se = use_se
        self.stride = stride
        self.drop_rate = drop_rate
        self.index = index

    @staticmethod
    def adjust_channels(channels: int, width_coefficient: float):
        return _make_divisible(channels * width_coefficient, 8)


class InvertedResidual(nn.Module):
    def __init__(self,
                 cnf,
                 norm_layer):
        super(InvertedResidual, self).__init__()

        if cnf.stride not in [1, 2]:
            raise ValueError("illegal stride value.")

        self.use_res_connect = (cnf.stride == 1 and cnf.input_c == cnf.out_c)

        layers = OrderedDict()
        activation_layer = nn.SiLU  # alias Swish

        # expand
        if cnf.expanded_c != cnf.input_c:
            layers.update({"expand_conv": ConvBNActivation(cnf.input_c,
                                                           cnf.expanded_c,
                                                           kernel_size=1,
                                                           norm_layer=norm_layer,
                                                           activation_layer=activation_layer)})

        # depthwise
        layers.update({"dwconv": ConvBNActivation(cnf.expanded_c,
                                                  cnf.expanded_c,
                                                  kernel_size=cnf.kernel,
                                                  stride=cnf.stride,
                                                  groups=cnf.expanded_c,
                                                  norm_layer=norm_layer,
                                                  activation_layer=activation_layer)})

        if cnf.use_se:
            layers.update({"se": SqueezeExcitation(cnf.input_c,
                                                   cnf.expanded_c)})

        # project
        layers.update({"project_conv": ConvBNActivation(cnf.expanded_c,
                                                        cnf.out_c,
                                                        kernel_size=1,
                                                        norm_layer=norm_layer,
                                                        activation_layer=nn.Identity)})

        self.block = nn.Sequential(layers)
        self.out_channels = cnf.out_c
        self.is_strided = cnf.stride > 1

        # 只有在使用shortcut连接时才使用dropout层
        if self.use_res_connect and cnf.drop_rate > 0:
            self.dropout = DropPath(cnf.drop_rate)
        else:
            self.dropout = nn.Identity()

    def forward(self, x):
        result = self.block(x)
        result = self.dropout(result)
        if self.use_res_connect:
            result += x

        return result


class EfficientNet(nn.Module):
    def __init__(self,
                 width_coefficient: float,
                 depth_coefficient: float,
                 num_classes: int = 2,
                 dropout_rate: float = 0.2,
                 drop_connect_rate: float = 0.2,
                 block= None,
                 norm_layer= None
                 ):
        super(EfficientNet, self).__init__()

        # kernel_size, in_channel, out_channel, exp_ratio, strides, use_SE, drop_connect_rate, repeats
        default_cnf = [[3, 32, 16, 1, 1, True, drop_connect_rate, 1],
                       [3, 16, 24, 6, 2, True, drop_connect_rate, 2],
                       [5, 24, 40, 6, 2, True, drop_connect_rate, 2],
                       [3, 40, 80, 6, 2, True, drop_connect_rate, 3],
                       [5, 80, 112, 6, 1, True, drop_connect_rate, 3],
                       [5, 112, 192, 6, 2, True, drop_connect_rate, 4],
                       [3, 192, 320, 6, 1, True, drop_connect_rate, 1]]

        def round_repeats(repeats):
            """Round number of repeats based on depth multiplier."""
            return int(math.ceil(depth_coefficient * repeats))

        if block is None:
            block = InvertedResidual

        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, eps=1e-3, momentum=0.1)

        adjust_channels = partial(InvertedResidualConfig.adjust_channels,
                                  width_coefficient=width_coefficient)

        # build inverted_residual_setting
        bneck_conf = partial(InvertedResidualConfig,
                             width_coefficient=width_coefficient)

        b = 0
        num_blocks = float(sum(round_repeats(i[-1]) for i in default_cnf))
        inverted_residual_setting = []
        for stage, args in enumerate(default_cnf):
            cnf = copy.copy(args)
            for i in range(round_repeats(cnf.pop(-1))):
                if i > 0:
                    # strides equal 1 except first cnf
                    cnf[-3] = 1  # strides
                    cnf[1] = cnf[2]  # input_channel equal output_channel

                cnf[-1] = args[-2] * b / num_blocks  # update dropout ratio
                index = str(stage + 1) + chr(i + 97)  # 1a, 2a, 2b, ...
                inverted_residual_setting.append(bneck_conf(*cnf, index))
                b += 1

        # create layers
        layers = OrderedDict()

        # first conv
        layers.update({"stem_conv": ConvBNActivation(in_planes=3,
                                                     out_planes=adjust_channels(32),
                                                     kernel_size=3,
                                                     stride=2,
                                                     norm_layer=norm_layer)})

        # building inverted residual blocks
        for cnf in inverted_residual_setting:
            layers.update({cnf.index: block(cnf, norm_layer)})

        # build top
        last_conv_input_c = inverted_residual_setting[-1].out_c
        last_conv_output_c = adjust_channels(1280)
        layers.update({"top": ConvBNActivation(in_planes=last_conv_input_c,
                                               out_planes=last_conv_output_c,
                                               kernel_size=1,
                                               norm_layer=norm_layer)})

        self.features = nn.Sequential(layers)
        self.avgpool = nn.AdaptiveAvgPool2d(1)

        classifier = []
        if dropout_rate > 0:
            classifier.append(nn.Dropout(p=dropout_rate, inplace=True))
        classifier.append(nn.Linear(last_conv_output_c, num_classes))
        self.classifier = nn.Sequential(*classifier)

        # initial weights
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

    def _forward_impl(self, x: Tensor) -> Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)

        return x

    def forward(self, x: Tensor) -> Tensor:
        return self._forward_impl(x)


def efficientnet_b0(num_classes=2):
    # input image size 224x224
    return EfficientNet(width_coefficient=1.0,
                        depth_coefficient=1.0,
                        dropout_rate=0.2,
                        num_classes=num_classes)
import os 
import cv2
import torch
from PIL import Image
from torch.utils.data import DataLoader,Dataset,random_split
from torchvision import transforms
import numpy as np
###########设置自己的数据库
class yolovdataset(Dataset):
    def __init__(self,img_path,transforms):
        self.img_path=img_path
        self.filenames=os.listdir(img_path)
        self.transforms=transforms    
    def __len__(self):
        return len(self.filenames)
    def __getitem__(self,idx):
        img=cv2.imread(os.path.join(self.img_path,self.filenames[idx]))
        img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        img=Image.fromarray(img).convert('RGB')
        img=self.transforms(img)
        if self.filenames[idx][0]=='1':####如果图片文件名的第一个为“1”，则为正常数据。该操作依据数据的特点而来。
            label=[1.0,0.0]
        else:####如果图片文件名的第一个不为“1”，则为异常数据
            label=[0.0,1.0]
        label=torch.tensor(label) #####转化为tensor类型
        return img,label
################这个函数可以将数据集变为训练集和测试集
def create_dataloader(img_path,train_proportion,test_porportion, batch_size):
    ######数据集预处理
    transform=transforms.Compose([transforms.Resize((400,400)),transforms.ToTensor()])
    #生成整体数据集
    dataset=yolovdataset(img_path,transform)
    #数据集的数据个数
    dataset_size=len(dataset)
    #自己想要设置的训练集数据个数
    train_size=int(dataset_size*train_proportion)
    test_size=dataset_size-train_size
    ###随机划分数据集和测试集
    train_dataset,test_dataset=random_split(dataset, [train_size,test_size])
    #生成测试集
    train_loader=DataLoader(train_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    #生成测试集
    test_loader=DataLoader(test_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    return train_loader,test_loader


if __name__ == '__main__':
    #调用函数生成训练集与测试集，第一个参数为数据文件
    train_dataloader,test_dataloader=create_dataloader(r"/root/autodl-tmp/end",0.6,0.4,6)
    test_len=len(test_dataloader)
    mymodule =efficientnet_b0()

    mymodule.to('cuda')
    loss =torch.nn.MSELoss().to('cuda')
    learnstep = 0.0001
    optim = torch.optim.SGD(mymodule.parameters(),lr=learnstep,weight_decay=0.0005)
    epoch = 40
    x=[]#####保存准确度
    y=[]#####保存损失
    train_step = 0 #每轮训练的次数
    mymodule.train()#模型在训练状态

    for i in range(epoch):
        print("第{}轮训练".format(i+1))
        total_loss=0
        train_step = 0 
        for data in train_dataloader:
            imgs,targets = data
            imgs=imgs.view(-1,3,400,400)/255
            imgs=imgs.to('cuda')
            targets=targets.to('cuda')          
            outputs = mymodule(imgs)
            result_loss = loss(outputs,targets)
            total_loss+=result_loss
            optim.zero_grad()
            result_loss.backward()
            optim.step()
            train_step +=1
            if ( train_step%30==0):
                print(train_step)
           
        print("损失",total_loss/train_step)
        y.append(total_loss/train_step)
        # 在测试集上面的效果
        mymodule.eval() #在验证状态
        test_total_loss = 0
        right_number = 0
        acc_num = torch.zeros((1, 2))
        target_num = torch.zeros((1, 2)) 
        predict_num = torch.zeros((1,2))
        with torch.no_grad(): # 验证的部分，不是训练所以不要带入梯度
            for test_data  in test_dataloader:
                imgs,label = test_data
                imgs=imgs.view(-1,3,400,400)/255
                imgs=imgs.to('cuda')
                label=label.to('cuda')
                outputs_ = mymodule(imgs)
                test_result_loss=loss(outputs_,label)
                right_number += (outputs_.argmax(1)==label.argmax(1)).sum()
                _, predicted_ = outputs_.max(1)
                _, label_ = label.max(1)
                pre_mask = torch.zeros(outputs_.size()).scatter_(1, predicted_.cpu().view(-1, 1), 1.)
                predict_num += pre_mask.sum(0)  # 得到数据中每类的预测量
                tar_mask = torch.zeros(outputs_.size()).scatter_(1, label_.cpu().view(-1, 1), 1.)
                target_num += tar_mask.sum(0)  # 得到数据中每类的数量
                acc_mask = pre_mask * tar_mask 
                acc_num += acc_mask.sum(0) # 得到各类别分类正确的样本数量
                train_step +=1
                if ( train_step%30==0):
                    print(train_step)
            recall = acc_num / target_num
            precision = acc_num /predict_num
            F1 = 2 * recall * precision / (recall + precision)


            print(i,(right_number/(6*test_len)),precision,recall,F1)
            x.append(right_number/(6*test_len))
            
    torch.save(mymodule.state_dict(), 'model.pth')

    ########绘制训练损失图与模型准确度图
    import matplotlib.pyplot as plt
    import numpy as np
    y=torch.tensor(y.copy())
    x=torch.tensor(x.copy())
    y=y.cpu().numpy()
    x=x.cpu().numpy()
    fig=plt.figure()
    ax1=fig.subplots()
    ax2=ax1.twinx()   
    ax1.plot(range(len(x)),x,'g-',color='red',label='Testing-Accuracy')
    ax2.plot(range(len(y)),y,'b--',color='orange',label='Training-Error')
    ax1.scatter(range(len(x)),x,marker='^',color='orange',s=20)
    ax2.scatter(range(len(y)),y,marker='*',color='red',s=20)
    ax1.set_xlabel('epoch',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax2.set_ylabel('Error',fontsize=18)
    ax1.set_xticks([])
    ax2.set_xticks([])
    fig.legend()   
    plt.savefig('./autodl-tmp/pic-{}.png'.format( 1))
    plt.show()    