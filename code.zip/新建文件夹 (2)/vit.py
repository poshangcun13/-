# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 22:49:43 2024

@author: lenovo
"""

import torch
from torch import nn
from functools import partial


class patchembed(nn.Module):
    # 初始化
    def __init__(self, img_size=224, patch_size=16, in_c=3, embed_dim=768):
        super(patchembed, self).__init__()

        # 输入图像的尺寸224*224
        self.img_size = (img_size, img_size)
        # 每个patch的大小16*16
        self.patch_size = (patch_size, patch_size)
        # 将输入图像划分成14*14个patch
        self.grid_size = (img_size // patch_size, img_size // patch_size)
        # 一共有14*14个patch      224/16  *  224/16
        self.num_patches = self.grid_size[0] * self.grid_size[1]

        # 使用16*16的卷积切分图像，将图像分成14*14个
        self.proj = nn.Conv2d(in_channels=in_c, out_channels=embed_dim,
                              kernel_size=patch_size, stride=patch_size)

        # 定义标准化方法，给LN传入默认参数eps
        norm_layer = partial(nn.LayerNorm, eps=1e-6)
        self.norm = norm_layer(embed_dim)#  标准化是什么


    # 前向传播
    def forward(self, inputs):
        # 获得输入图像的shape
        B, C, H, W = inputs.shape

        # 如果输入图像的宽高不等于224*224就报错
        '''
        重要写法   inputshape！=224就会报错误
        '''
        assert H == self.img_size[0] and W == self.img_size[1], 'input shape does not match 224*224'

        # 卷积层切分patch [b,3,224,224]==>[b,768,14,14]
        x = self.proj(inputs)
        # 展平 [b,768,14,14]==>[b,768,14*14]
        x = x.flatten(start_dim=2, end_dim=-1)  # 将索引为 start_dim 和 end_dim 之间（包括该位置）的数量相乘
        # 维度调整 [b,768,14*14]==>[b,14*14,768]
        x = x.transpose(1, 2)  # 实现一个张量的两个轴之间的维度转换
        # 标准化
        x = self.norm(x)

        return x


# --------------------------------------- #
# （2）类别标签和位置标签
'''
embed_dim : 代表patchembed层输出的通道数
'''


# --------------------------------------- #
class class_token_pos_embed(nn.Module):
    # 初始化
    def __init__(self, embed_dim):
        super(class_token_pos_embed, self).__init__()

        # patchembed层将图像划分的patch个数==14*14
        num_patches = patchembed().num_patches

        self.num_tokens = 1  # 类别标签

        # 创建可学习的类别标签 [1,1,768]
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        # 创建可学习的位置编码 [1,196+1,768]
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + self.num_tokens, embed_dim))

        # 权重以正态分布初始化
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.cls_token, std=0.02)

    # 前向传播
    def forward(self, x):  # 输入特征图的shape=[b,196,768]

        # 类别标签扩充维度 [1,1,768]==>[b,1,768]
        cls_token = self.cls_token.expand(x.shape[0], -1, -1)

        # 将类别标签添加到特征图中 [b,1,768]+[b,196,768]==>[b,197,768]
        x = torch.cat((cls_token, x), dim=1)

        # 添加位置编码 [b,197,768]+[1,197,768]==>[b,197,768]
        x = x + self.pos_embed

        return x


# --------------------------------------- #
# （3）多头注意力模块
'''
dim : 代表输入特征图的通道数
num_heads : 多头注意力中heads的个数
qkv_bias ： 生成qkv时是否使用偏置 
atten_drop_ratio ：qk计算完之后的dropout层
proj_drop_ratio ： qkv计算完成之后的dropout层
'''


# --------------------------------------- #
class attention(nn.Module):
    # 初始化
    def __init__(self, dim, num_heads=12, qkv_bias=False, atten_drop_ratio=0., proj_drop_ratio=0.):
        super(attention, self).__init__()

        # 多头注意力的数量
        self.num_heads = num_heads
        # 将生成的qkv均分成num_heads个。得到每个head的qkv对应的通道数。
        head_dim = dim // num_heads
        print(dim)
        # 公式中的分母
        self.scale = head_dim ** -0.5

        # 通过一个全连接层计算qkv
        self.qkv = nn.Linear(in_features=dim, out_features=dim * 3, bias=qkv_bias)
        # dropout层
        self.atten_drop = nn.Dropout(atten_drop_ratio)

        # 再qkv计算完之后通过一个全连接提取特征
        self.proj = nn.Linear(in_features=dim, out_features=dim)
        # dropout层
        self.proj_drop = nn.Dropout(proj_drop_ratio)

    # 前向传播
    def forward(self, inputs):
        # 获取输入图像的shape=[b,197,768]
        B, N, C = inputs.shape

        # 将输入特征图经过全连接层生成qkv [b,197,768]==>[b,197,768*3]
        qkv = self.qkv(inputs)

        # 维度调整 [b,197,768*3]==>[b, 197, 3, 12, 768//12]
        qkv = qkv.reshape(B, N, 3, self.num_heads, C // self.num_heads)
        # 维度重排==> [3, B, 12, 197, 768//12]
        qkv = qkv.permute(2, 0, 3, 1, 4)
        # 切片提取q、k、v的值，单个的shape=[B, 12, 197, 768//12]
        q, k, v = qkv[0], qkv[1], qkv[2]

        # 针对每个head计算 ==> [B, 12, 197, 197]
        atten = (q @ k.transpose(-2, -1)) * self.scale  # @ 代表在多维tensor的最后两个维度矩阵相乘
        # 对计算结果的每一行经过softmax
        atten = atten.softmax(dim=-1)
        # dropout层
        atten = self.atten_drop(atten)

        # softmax后的结果和v加权 ==> [B, 12, 197, 768//12]
        x = atten @ v
        # 通道重排 ==> [B, 197, 12, 768//12]
        x = x.transpose(1, 2)
        # 维度调整 ==> [B, 197, 768]
        x = x.reshape(B, N, C)

        # 通过全连接层融合特征 ==> [B, 197, 768]
        x = self.proj(x)
        # dropout层
        x = self.proj_drop(x)

        return x


# --------------------------------------- #
# （4）MLP多层感知器
'''
in_features : 输入特征图的通道数
hidden_features : 第一个全连接层上升通道数
out_features : 第二个全连接层的下降的通道数
drop : 全连接层后面的dropout层的杀死神经元的概率
'''


# --------------------------------------- #
class MLP(nn.Module):
    # 初始化
    def __init__(self, in_features, hidden_features, out_features=None, drop=0.):
        super(MLP, self).__init__()

        # MLP的输出通道数默认等于输入通道数
        out_features = out_features or in_features
        # 第一个全连接层上升通道数
        self.fc1 = nn.Linear(in_features=in_features, out_features=hidden_features)
        # GeLU激活函数
        self.act = nn.GELU()
        # 第二个全连接下降通道数
        self.fc2 = nn.Linear(in_features=hidden_features, out_features=out_features)
        # dropout层
        self.drop = nn.Dropout(drop)

    # 前向传播
    def forward(self, inputs):
        # [b,197,768]==>[b,197,3072]
        x = self.fc1(inputs)
        x = self.act(x)
        x = self.drop(x)

        # [b,197,3072]==>[b,197,768]
        x = self.fc2(x)
        x = self.drop(x)

        return x


# --------------------------------------- #
# （5）Encoder Block
'''
dim : 该模块的输入特征图个数
mlp_ratio ： MLP中第一个全连接层上升的通道数
drop_ratio : 该模块的dropout层的杀死神经元的概率
'''


# --------------------------------------- #
class encoder_block(nn.Module):
    # 初始化
    def __init__(self, dim, mlp_ratio=4., drop_ratio=0.):
        super(encoder_block, self).__init__()

        # LayerNormalization层
        self.norm1 = nn.LayerNorm(dim)
        # 实例化多头注意力
        self.atten = attention(dim)
        # dropout
        self.drop = nn.Dropout()

        # LayerNormalization层
        self.norm2 = nn.LayerNorm(dim)
        # MLP中第一个全连接层上升的通道数
        hidden_features = int(dim * mlp_ratio)
        # MLP多层感知器
        self.mlp = MLP(in_features=dim, hidden_features=hidden_features)

    # 前向传播
    def forward(self, inputs):
        # [b,197,768]==>[b,197,768]
        x = self.norm1(inputs)
        x = self.atten(x)
        x = self.drop(x)
        feat1 = x + inputs  # 残差连接

        # [b,197,768]==>[b,197,768]
        x = self.norm2(feat1)
        x = self.mlp(x)
        x = self.drop(x)
        feat2 = x + feat1  # 残差连接

        return feat2


# --------------------------------------- #
# （6）主干网络
'''
num_class: 分类数
depth : 重复堆叠encoder_block的次数
drop_ratio : 位置编码后的dropout层
embed_dim : patchembed层输出通道数
'''


# --------------------------------------- #
class VIT(nn.Module):
    # 初始化
    def __init__(self, num_classes=1000, depth=12, drop_ratio=0., embed_dim=768):
        super(VIT, self).__init__()

        self.num_classes = num_classes  # 分类类别数

        # 实例化patchembed层
        self.patchembed = patchembed()

        # 实例化类别标签和位置编码
        self.cls_pos_embed = class_token_pos_embed(embed_dim=embed_dim)

        # 位置编码后做dropout
        self.pos_drop = nn.Dropout(drop_ratio)

        # 在列表中添加12个encoder_block
        self.blocks = nn.Sequential(*[encoder_block(dim=embed_dim) for _ in range(depth)])

        # 定义LayerNormalization标准化方法
        norm_layer = partial(nn.LayerNorm, eps=1e-6)
        # 经过12个encoder之后的标准化层
        self.norm = norm_layer(embed_dim)

        # 分类层
        self.head = nn.Linear(in_features=embed_dim, out_features=num_classes)

        # 权值初始化
        for m in self.modules():
            # 对卷积层使用kaiming初始化
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                # 对偏置初始化
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            # 对标准化层初始化
            elif isinstance(m, nn.LayerNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            # 对全连接层初始化
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    # 前向传播
    def forward(self, inputs):

        # 先将输入传递给patchembed [b,3,224,224]==>[b,196,768]
        x = self.patchembed(inputs)

        # 对特征图添加类别标签和位置编码
        x = self.cls_pos_embed(x)

        # dropout层
        x = self.pos_drop(x)

        # 经过12个encoder层==>[b,197,768]
        x = self.blocks(x)

        # LN标准化层
        x = self.norm(x)

        # 提取类别标签的输出,因为在cat时将类别标签放在最前面
        x = x[:, 0]  # [b,197,768]==>[b,768]

        # 全连接层分类 [b,768]==>[b,1000]
        x = self.head(x)

        return x


from torch.nn import CrossEntropyLoss, Dropout, Softmax, Linear, Conv2d, LayerNorm
import os 
import cv2
import torch
from PIL import Image
from torch.utils.data import DataLoader,Dataset,random_split
from torchvision import transforms
import numpy as np
###########设置自己的数据库
class yolovdataset(Dataset):
    def __init__(self,img_path,transforms):
        self.img_path=img_path
        self.filenames=os.listdir(img_path)
        self.transforms=transforms    
    def __len__(self):
        return len(self.filenames)
    def __getitem__(self,idx):
        img=cv2.imread(os.path.join(self.img_path,self.filenames[idx]))
        img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        img=Image.fromarray(img).convert('RGB')
        img=self.transforms(img)
        if self.filenames[idx][0]=='1':####如果图片文件名的第一个为“1”，则为正常数据。该操作依据数据的特点而来。
            label=[1.0,0.0]
        else:####如果图片文件名的第一个不为“1”，则为异常数据
            label=[0.0,1.0]
        label=torch.tensor(label) #####转化为tensor类型
        return img,label
################这个函数可以将数据集变为训练集和测试集
def create_dataloader(img_path,train_proportion,test_porportion, batch_size):
    ######数据集预处理
    transform=transforms.Compose([transforms.Resize((224,224)),transforms.ToTensor()])
    #生成整体数据集
    dataset=yolovdataset(img_path,transform)
    #数据集的数据个数
    dataset_size=len(dataset)
    #自己想要设置的训练集数据个数
    train_size=int(dataset_size*train_proportion)
    test_size=dataset_size-train_size
    ###随机划分数据集和测试集
    train_dataset,test_dataset=random_split(dataset, [train_size,test_size])
    #生成测试集
    train_loader=DataLoader(train_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    #生成测试集
    test_loader=DataLoader(test_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    return train_loader,test_loader


if __name__ == '__main__':
    #调用函数生成训练集与测试集，第一个参数为数据文件
    train_dataloader,test_dataloader=create_dataloader(r"/root/autodl-tmp/end",0.6,0.4,20)
    test_len=len(test_dataloader)
    mymodule =VIT(2,1)


    mymodule.to('cuda')
    loss= CrossEntropyLoss().to('cuda')
    learnstep =0.00001
    optim = torch. optim.Adam(mymodule.parameters(),lr=learnstep,weight_decay=0.0005)
    epoch = 40
    x=[]#####保存准确度
    y=[]#####保存损失
    train_step = 0 #每轮训练的次数
    mymodule.train()#模型在训练状态

    for i in range(epoch):
        print("第{}轮训练".format(i+1))
        total_loss=0
        train_step = 0 
        for data in train_dataloader:
            imgs,targets = data
            imgs=imgs.view(-1,3,224,224)
            imgs=imgs.to('cuda')
            targets=targets.to('cuda')          
            outputs = mymodule(imgs)
            result_loss = loss(outputs,targets)
            total_loss+=result_loss
            optim.zero_grad()
            result_loss.backward()
           # for param_tensor in mymodule.state_dict(): # 字典的遍历默认是遍历 key，所以param_tensor实际上是键值
              #  print(param_tensor,'\t',mymodule.state_dict()[param_tensor][0])
               # break

            optim.step()
            train_step +=1
            if ( train_step%30==0):
                print(train_step)
           
        print("损失",total_loss/train_step)
        y.append(total_loss/train_step)
        # 在测试集上面的效果
        mymodule.eval() #在验证状态
        test_total_loss = 0
        right_number = 0
        acc_num = torch.zeros((1, 2))
        target_num = torch.zeros((1, 2)) 
        predict_num = torch.zeros((1,2))
        with torch.no_grad(): # 验证的部分，不是训练所以不要带入梯度
            for test_data  in test_dataloader:
                imgs,label = test_data
                imgs=imgs.view(-1,3,224,224)
                imgs=imgs.to('cuda')
                label=label.to('cuda')
                outputs_ = mymodule(imgs)
                test_result_loss=loss(outputs_,label)
                right_number += (outputs_.argmax(1)==label.argmax(1)).sum()
                _, predicted_ = outputs_.max(1)
                _, label_ = label.max(1)
                pre_mask = torch.zeros(outputs_.size()).scatter_(1, predicted_.cpu().view(-1, 1), 1.)
                predict_num += pre_mask.sum(0)  # 得到数据中每类的预测量
                tar_mask = torch.zeros(outputs_.size()).scatter_(1, label_.cpu().view(-1, 1), 1.)
                target_num += tar_mask.sum(0)  # 得到数据中每类的数量
                acc_mask = pre_mask * tar_mask 
                acc_num += acc_mask.sum(0) # 得到各类别分类正确的样本数量
                train_step +=1
                if ( train_step%30==0):
                    print(train_step)
            recall = acc_num / target_num
            precision = acc_num /predict_num
            F1 = 2 * recall * precision / (recall + precision)


            print(i,(right_number/(20*test_len)),precision,recall,F1)
            x.append(right_number/(6*test_len))
            
    torch.save(mymodule.state_dict(), 'model.pth')

    ########绘制训练损失图与模型准确度图
    import matplotlib.pyplot as plt
    import numpy as np
    y=torch.tensor(y.copy())
    x=torch.tensor(x.copy())
    y=y.cpu().numpy()
    x=x.cpu().numpy()
    fig=plt.figure()
    ax1=fig.subplots()
    ax2=ax1.twinx()   
    ax1.plot(range(len(x)),x,'g-',color='red',label='Testing-Accuracy')
    ax2.plot(range(len(y)),y,'b--',color='orange',label='Training-Error')
    ax1.scatter(range(len(x)),x,marker='^',color='orange',s=20)
    ax2.scatter(range(len(y)),y,marker='*',color='red',s=20)
    ax1.set_xlabel('epoch',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax2.set_ylabel('Error',fontsize=18)
    ax1.set_xticks([])
    ax2.set_xticks([])
    fig.legend()   
    plt.savefig('./autodl-tmp/pic-{}.png'.format( 1))
    plt.show()    