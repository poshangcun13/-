# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 07:52:36 2024

@author: lenovo
"""
"""
Created on Mon May 13 19:21:09 2024

@author: lenovo
"""
from torch import nn
import torch
import torch.nn.functional as F
import torch
import torch.nn as nn

def Conv1(in_planes, places, stride=2):
    return nn.Sequential(
        nn.Conv2d(in_channels=in_planes,out_channels=places,kernel_size=7,stride=stride,padding=3, bias=False),
        nn.BatchNorm2d(places),
        nn.ReLU(inplace=True),
        nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
    )


class DenseBlock(nn.Module):
    def __init__(self, num_layers, inplances, growth_rate, bn_size , drop_rate=0):
        super(DenseBlock, self).__init__()
        layers = []
        # 随着layer层数的增加，每增加一层，输入的特征图就增加一倍growth_rate
        for i in range(num_layers):
            layers.append(_DenseLayer(inplances + i * growth_rate, growth_rate, bn_size, drop_rate))
        self.layers = nn.Sequential(*layers)
 
    def forward(self, x):
        return self.layers(x)
class _DenseLayer(nn.Module):
    def __init__(self, inplace, growth_rate, bn_size, drop_rate=0):
        super(_DenseLayer, self).__init__()
        self.drop_rate = drop_rate
        self.dense_layer = nn.Sequential(
            nn.BatchNorm2d(inplace),
            nn.ReLU(inplace=True),
           # growth_rate：增长率。一层产生多少个特征图
            nn.Conv2d(in_channels=inplace, out_channels=bn_size * growth_rate, kernel_size=1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(bn_size * growth_rate),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=bn_size * growth_rate, out_channels=growth_rate, kernel_size=3, stride=1, padding=1, bias=False),
        )
        self.dropout = nn.Dropout(p=self.drop_rate)
 
    def forward(self, x):
        y = self.dense_layer(x)
        if self.drop_rate > 0:
            y = self.dropout(y)
        return torch.cat([x, y], 1)

class _TransitionLayer(nn.Module):
    def __init__(self, inplace, plance):
        super(_TransitionLayer, self).__init__()
        self.transition_layer = nn.Sequential(
            nn.BatchNorm2d(inplace),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=inplace,out_channels=plance,kernel_size=1,stride=1,padding=0,bias=False),
            nn.AvgPool2d(kernel_size=2,stride=2),
        )
 
    def forward(self, x):
        return self.transition_layer(x)

class DenseNet(nn.Module):
    def __init__(self, init_channels=64, growth_rate=32, blocks=[6, 12, 24, 16],num_classes=10):
        super(DenseNet, self).__init__()
        bn_size = 4
        drop_rate = 0
        self.conv1 = Conv1(in_planes=3, places=init_channels)
 
        blocks*4
 
        #第一次执行特征的维度来自于前面的特征提取
        num_features = init_channels
 
        # 第1个DenseBlock有6个DenseLayer, 执行DenseBlock（6,64,32,4）
        self.layer1 = DenseBlock(num_layers=blocks[0], inplances=num_features, growth_rate=growth_rate, bn_size=bn_size, drop_rate=drop_rate)
        num_features = num_features + blocks[0] * growth_rate
        # 第1个transition 执行 _TransitionLayer（256,128）
        self.transition1 = _TransitionLayer(inplace=num_features, plance=num_features // 2)
        #num_features减少为原来的一半，执行第1回合之后，第2个DenseBlock的输入的feature应该是：num_features = 128
        num_features = num_features // 2
 
        # 第2个DenseBlock有12个DenseLayer, 执行DenseBlock（12,128,32,4）
        self.layer2 = DenseBlock(num_layers=blocks[1], inplances=num_features, growth_rate=growth_rate, bn_size=bn_size, drop_rate=drop_rate)
        num_features = num_features + blocks[1] * growth_rate
        # 第2个transition 执行 _TransitionLayer（512,256）
        self.transition2 = _TransitionLayer(inplace=num_features, plance=num_features // 2)
        # num_features减少为原来的一半，执行第2回合之后，第3个DenseBlock的输入的feature应该是：num_features = 256
        num_features = num_features // 2
 
        # 第3个DenseBlock有24个DenseLayer, 执行DenseBlock（24,256,32,4）
        self.layer3 = DenseBlock(num_layers=blocks[2], inplances=num_features, growth_rate=growth_rate, bn_size=bn_size, drop_rate=drop_rate)
        num_features = num_features + blocks[2] * growth_rate
        # 第3个transition 执行 _TransitionLayer（1024,512）
        self.transition3 = _TransitionLayer(inplace=num_features, plance=num_features // 2)
        # num_features减少为原来的一半，执行第3回合之后，第4个DenseBlock的输入的feature应该是：num_features = 512
        num_features = num_features // 2
 
        # 第4个DenseBlock有16个DenseLayer, 执行DenseBlock（16,512,32,4）
        self.layer4 = DenseBlock(num_layers=blocks[3], inplances=num_features, growth_rate=growth_rate, bn_size=bn_size, drop_rate=drop_rate)
        num_features = num_features + blocks[3] * growth_rate
 
        self.avgpool = nn.AvgPool2d(7, stride=1)
        self.fc = nn.Linear(num_features*36, num_classes)
 
    def forward(self, x):
        x = self.conv1(x)
 
        x = self.layer1(x)
        x = self.transition1(x)
        x = self.layer2(x)
        x = self.transition2(x)
        x = self.layer3(x)
        x = self.transition3(x)
        x = self.layer4(x)
 
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x
import os 
import cv2
import torch
from PIL import Image
from torch.utils.data import DataLoader,Dataset,random_split
from torchvision import transforms
import numpy as np
###########设置自己的数据库
class yolovdataset(Dataset):
    def __init__(self,img_path,transforms):
        self.img_path=img_path
        self.filenames=os.listdir(img_path)
        self.transforms=transforms    
    def __len__(self):
        return len(self.filenames)
    def __getitem__(self,idx):
        img=cv2.imread(os.path.join(self.img_path,self.filenames[idx]))
        img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        img=Image.fromarray(img).convert('RGB')
        img=self.transforms(img)
        if self.filenames[idx][0]=='1':####如果图片文件名的第一个为“1”，则为正常数据。该操作依据数据的特点而来。
            label=[1.0,0.0]
        else:####如果图片文件名的第一个不为“1”，则为异常数据
            label=[0.0,1.0]
        label=torch.tensor(label) #####转化为tensor类型
        return img,label
################这个函数可以将数据集变为训练集和测试集
def create_dataloader(img_path,train_proportion,test_porportion, batch_size):
    ######数据集预处理
    transform=transforms.Compose([transforms.Resize((400,400)),transforms.ToTensor()])
    #生成整体数据集
    dataset=yolovdataset(img_path,transform)
    #数据集的数据个数
    dataset_size=len(dataset)
    #自己想要设置的训练集数据个数
    train_size=int(dataset_size*train_proportion)
    test_size=dataset_size-train_size
    ###随机划分数据集和测试集
    train_dataset,test_dataset=random_split(dataset, [train_size,test_size])
    #生成测试集
    train_loader=DataLoader(train_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    #生成测试集
    test_loader=DataLoader(test_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    return train_loader,test_loader


if __name__ == '__main__':
    #调用函数生成训练集与测试集，第一个参数为数据文件
    train_dataloader,test_dataloader=create_dataloader(r"/root/autodl-tmp/end",0.6,0.4,6)
    test_len=len(test_dataloader)
    mymodule = DenseNet()

    mymodule.to('cuda')
    loss =torch.nn.MSELoss().to('cuda')
    learnstep = 0.0001
    optim = torch.optim.SGD(mymodule.parameters(),lr=learnstep,weight_decay=0.0005)
    epoch = 40
    x=[]#####保存准确度
    y=[]#####保存损失
    train_step = 0 #每轮训练的次数
    mymodule.train()#模型在训练状态

    for i in range(epoch):
        print("第{}轮训练".format(i+1))
        total_loss=0
        train_step = 0 
        for data in train_dataloader:
            imgs,targets = data
            imgs=imgs.view(-1,3,400,400)/255
            imgs=imgs.to('cuda')
            targets=targets.to('cuda')          
            outputs = mymodule(imgs)
            result_loss = loss(outputs,targets)
            total_loss+=result_loss
            optim.zero_grad()
            result_loss.backward()
            optim.step()
            train_step +=1
            if ( train_step%30==0):
                print(train_step)
           
        print("损失",total_loss/train_step)
        y.append(total_loss/train_step)
        # 在测试集上面的效果
        mymodule.eval() #在验证状态
        test_total_loss = 0
        right_number = 0
        acc_num = torch.zeros((1, 2))
        target_num = torch.zeros((1, 2)) 
        predict_num = torch.zeros((1,2))
        with torch.no_grad(): # 验证的部分，不是训练所以不要带入梯度
            for test_data  in test_dataloader:
                imgs,label = test_data
                imgs=imgs.view(-1,3,400,400)/255
                imgs=imgs.to('cuda')
                label=label.to('cuda')
                outputs_ = mymodule(imgs)
                test_result_loss=loss(outputs_,label)
                right_number += (outputs_.argmax(1)==label.argmax(1)).sum()
                _, predicted_ = outputs_.max(1)
                _, label_ = label.max(1)
                pre_mask = torch.zeros(outputs_.size()).scatter_(1, predicted_.cpu().view(-1, 1), 1.)
                predict_num += pre_mask.sum(0)  # 得到数据中每类的预测量
                tar_mask = torch.zeros(outputs_.size()).scatter_(1, label_.cpu().view(-1, 1), 1.)
                target_num += tar_mask.sum(0)  # 得到数据中每类的数量
                acc_mask = pre_mask * tar_mask 
                acc_num += acc_mask.sum(0) # 得到各类别分类正确的样本数量
                train_step +=1
                if ( train_step%30==0):
                    print(train_step)
            recall = acc_num / target_num
            precision = acc_num /predict_num
            F1 = 2 * recall * precision / (recall + precision)


            print(i,(right_number/(6*test_len)),precision,recall,F1)
            x.append(right_number/(6*test_len))
            
    torch.save(mymodule.state_dict(), 'model.pth')

    ########绘制训练损失图与模型准确度图
    import matplotlib.pyplot as plt
    import numpy as np
    y=torch.tensor(y.copy())
    x=torch.tensor(x.copy())
    y=y.cpu().numpy()
    x=x.cpu().numpy()
    fig=plt.figure()
    ax1=fig.subplots()
    ax2=ax1.twinx()   
    ax1.plot(range(len(x)),x,'g-',color='red',label='Testing-Accuracy')
    ax2.plot(range(len(y)),y,'b--',color='orange',label='Training-Error')
    ax1.scatter(range(len(x)),x,marker='^',color='orange',s=20)
    ax2.scatter(range(len(y)),y,marker='*',color='red',s=20)
    ax1.set_xlabel('epoch',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax2.set_ylabel('Error',fontsize=18)
    ax1.set_xticks([])
    ax2.set_xticks([])
    fig.legend()   
    plt.savefig('./autodl-tmp/pic-{}.png'.format( 1))
    plt.show()    