# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 22:49:43 2024

@author: lenovo
"""

import torch
from torch import nn
from functools import partial


class patchembed(nn.Module):
    # 初始化
    def __init__(self, img_size=224, patch_size=16, in_c=3, embed_dim=768):
        super(patchembed, self).__init__()
    # 前向传播
    def forward(self, inputs):
        # 获得输入图像的shape
        B, C, H, W = inputs.shape
        x=inputs.reshape(-1,768,14*14)
        x = x.transpose(1, 2)  # 实现一个张量的两个轴之间的维度转
        return x




class attention(nn.Module):
    # 初始化
    def __init__(self, dim, num_heads=2, qkv_bias=False, atten_drop_ratio=0.0, proj_drop_ratio=0.0):
        super(attention, self).__init__()
        # 多头注意力的数量
        self.num_heads = num_heads
        # 将生成的qkv均分成num_heads个。得到每个head的qkv对应的通道数。
        head_dim = dim // num_heads
        # 公式中的分母
        self.scale = head_dim ** -0.5
        # 通过一个全连接层计算qkv
        self.qkv = nn.Linear(in_features=dim, out_features=dim*3 , bias=qkv_bias)
        # dropout
        self.atten_drop = nn.Dropout(atten_drop_ratio)

        # 再qkv计算完之后通过一个全连接提取特征
        self.proj = nn.Linear(in_features=dim, out_features=dim)
        # dropout层
        self.proj_drop = nn.Dropout(proj_drop_ratio)

    # 前向传播
    def forward(self, inputs):
        # 获取输入图像的shape=[b,197,768]
        B, N, C = inputs.shape
        # 将输入特征图经过全连接层生成qkv [b,197,768]==>[b,197,768*3]
        qkv = self.qkv(inputs)
        # 维度调整 [b,197,768*3]==>[b, 197, 3, 12, 768//12]
        qkv = qkv.reshape(B, N, 3, self.num_heads, C // self.num_heads)
        # 维度重排==> [3, B, 12, 197, 768//12]
        qkv = qkv.permute(2, 0, 3, 1, 4)
        # 切片提取q、k、v的值，单个的shape=[B, 12, 197, 768//12]
        q, k, v = qkv[0], qkv[1], qkv[2]
        # 针对每个head计算 ==> [B, 12, 197, 197]
        atten = (q @ k.transpose(-2, -1)) * self.scale  # @ 代表在多维tensor的最后两个维度矩阵相乘
        # 对计算结果的每一行经过softmax
        atten = atten.softmax(dim=-1)
        # dropout层
        atten = self.atten_drop(atten)
        # softmax后的结果和v加权 ==> [B, 12, 197, 768//12]
        x = atten @ v
        # 通道重排 ==> [B, 197, 12, 768//12]
        x = x.transpose(1, 2)
        # 维度调整 ==> [B, 197, 768]
        x = x.reshape(B, N, C)
        # 通过全连接层融合特征 ==> [B, 197, 768]
        x = self.proj(x)
        # dropout层
        x = self.proj_drop(x)
        return x



class encoder_block(nn.Module):
    # 初始化
    def __init__(self, dim, mlp_ratio=1., drop_ratio=0.):
        super(encoder_block, self).__init__()
        # 实例化多头注意力
        self.atten = attention(dim)
        # dropout
        self.drop = nn.Dropout()
        # LayerNormalization层
        self.norm2 = nn.LayerNorm(dim)
        # MLP中第一个全连接层上升的通道数
        hidden_features = int(dim * mlp_ratio)
        # MLP多层感知器
    # 前向传播
    def forward(self, inputs):
        x = self.atten(inputs)
        x = self.drop(x)
        feat1 = x + inputs  # 残差连接
        x = self.norm2(feat1)
        x = self.drop(x)
        feat2 = x + feat1  # 残差连接
        return feat2

# --------------------------------------- #
class transformer(nn.Module):
    # 初始化
    def __init__(self, num_classes=1000, depth=12, drop_ratio=0., embed_dim=768):
        super(transformer, self).__init__()
        self.num_classes = num_classes  # 分类类别数
        # 实例化patchembed层
        self.patchembed = patchembed()
        # 位置编码后做dropout
        self.pos_drop = nn.Dropout(drop_ratio)
        # 在列表中添加12个encoder_block
        self.blocks = nn.Sequential(*[encoder_block(dim=embed_dim) for _ in range(depth)])
        # 定义LayerNormalization标准化方法
        norm_layer = partial(nn.LayerNorm, eps=1e-6)
        # 分类层
        self.head = nn.Linear(in_features=embed_dim, out_features=num_classes)

        # 权值初始化
        for m in self.modules():
            # 对卷积层使用kaiming初始化
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                # 对偏置初始化
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            # 对标准化层初始化
            elif isinstance(m, nn.LayerNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            # 对全连接层初始化
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
    # 前向传播
    def forward(self, inputs):
        x = self.patchembed(inputs)
        x = self.pos_drop(x)
        x = self.blocks(x)
        x = x[:, 0]  # [b,197,768]==>[b,768]
        # 全连接层分类 [b,768]==>[b,1000]
        x = self.head(x)
        return x


from torch.nn import CrossEntropyLoss, Dropout, Softmax, Linear, Conv2d, LayerNorm
import os 
import cv2
import torch
from PIL import Image
from torch.utils.data import DataLoader,Dataset,random_split
from torchvision import transforms
import numpy as np
###########设置自己的数据库
class yolovdataset(Dataset):
    def __init__(self,img_path,transforms):
        self.img_path=img_path
        self.filenames=os.listdir(img_path)
        self.transforms=transforms    
    def __len__(self):
        return len(self.filenames)
    def __getitem__(self,idx):
        img=cv2.imread(os.path.join(self.img_path,self.filenames[idx]))
        img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        img=Image.fromarray(img).convert('RGB')
        img=self.transforms(img)
        if self.filenames[idx][0]=='1':####如果图片文件名的第一个为“1”，则为正常数据。该操作依据数据的特点而来。
            label=[1.0,0.0]
        else:####如果图片文件名的第一个不为“1”，则为异常数据
            label=[0.0,1.0]
        label=torch.tensor(label) #####转化为tensor类型
        return img,label
################这个函数可以将数据集变为训练集和测试集
def create_dataloader(img_path,train_proportion,test_porportion, batch_size):
    ######数据集预处理
    transform=transforms.Compose([transforms.Resize((224,224)),transforms.ToTensor()])
    #生成整体数据集
    dataset=yolovdataset(img_path,transform)
    #数据集的数据个数
    dataset_size=len(dataset)
    #自己想要设置的训练集数据个数
    train_size=int(dataset_size*train_proportion)
    test_size=dataset_size-train_size
    ###随机划分数据集和测试集
    train_dataset,test_dataset=random_split(dataset, [train_size,test_size])
    #生成测试集
    train_loader=DataLoader(train_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    #生成测试集
    test_loader=DataLoader(test_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    return train_loader,test_loader


if __name__ == '__main__':
    #调用函数生成训练集与测试集，第一个参数为数据文件
    train_dataloader,test_dataloader=create_dataloader(r"C:\Users\lenovo\Desktop\end1\end",0.6,0.4,20)
    test_len=len(test_dataloader)
    mymodule =transformer(2,1)


    mymodule.to('cuda')
    loss= CrossEntropyLoss().to('cuda')
    learnstep =0.00001
    optim = torch. optim.Adam(mymodule.parameters(),lr=learnstep,weight_decay=0.0005)
    epoch = 40
    x=[]#####保存准确度
    y=[]#####保存损失
    train_step = 0 #每轮训练的次数
    mymodule.train()#模型在训练状态

    for i in range(epoch):
        print("第{}轮训练".format(i+1))
        total_loss=0
        train_step = 0 
        for data in train_dataloader:
            imgs,targets = data
            imgs=imgs.view(-1,3,224,224)
            imgs=imgs.to('cuda')
            targets=targets.to('cuda')          
            outputs = mymodule(imgs)
            result_loss = loss(outputs,targets)
            total_loss+=result_loss
            optim.zero_grad()
            result_loss.backward()
           # for param_tensor in mymodule.state_dict(): # 字典的遍历默认是遍历 key，所以param_tensor实际上是键值
              #  print(param_tensor,'\t',mymodule.state_dict()[param_tensor][0])
               # break

            optim.step()
            train_step +=1
            if ( train_step%30==0):
                print(train_step)
           
        print("损失",total_loss/train_step)
        y.append(total_loss/train_step)
        # 在测试集上面的效果
        mymodule.eval() #在验证状态
        test_total_loss = 0
        right_number = 0
        acc_num = torch.zeros((1, 2))
        target_num = torch.zeros((1, 2)) 
        predict_num = torch.zeros((1,2))
        with torch.no_grad(): # 验证的部分，不是训练所以不要带入梯度
            for test_data  in test_dataloader:
                imgs,label = test_data
                imgs=imgs.view(-1,3,224,224)
                imgs=imgs.to('cuda')
                label=label.to('cuda')
                outputs_ = mymodule(imgs)
                test_result_loss=loss(outputs_,label)
                right_number += (outputs_.argmax(1)==label.argmax(1)).sum()
                _, predicted_ = outputs_.max(1)
                _, label_ = label.max(1)
                pre_mask = torch.zeros(outputs_.size()).scatter_(1, predicted_.cpu().view(-1, 1), 1.)
                predict_num += pre_mask.sum(0)  # 得到数据中每类的预测量
                tar_mask = torch.zeros(outputs_.size()).scatter_(1, label_.cpu().view(-1, 1), 1.)
                target_num += tar_mask.sum(0)  # 得到数据中每类的数量
                acc_mask = pre_mask * tar_mask 
                acc_num += acc_mask.sum(0) # 得到各类别分类正确的样本数量
                train_step +=1
                if ( train_step%30==0):
                    print(train_step)
            recall = acc_num / target_num
            precision = acc_num /predict_num
            F1 = 2 * recall * precision / (recall + precision)


            print(i,(right_number/(20*test_len)),precision,recall,F1)
            x.append(right_number/(6*test_len))
            
    torch.save(mymodule.state_dict(), 'model.pth')

    ########绘制训练损失图与模型准确度图
    import matplotlib.pyplot as plt
    import numpy as np
    y=torch.tensor(y.copy())
    x=torch.tensor(x.copy())
    y=y.cpu().numpy()
    x=x.cpu().numpy()
    fig=plt.figure()
    ax1=fig.subplots()
    ax2=ax1.twinx()   
    ax1.plot(range(len(x)),x,'g-',color='red',label='Testing-Accuracy')
    ax2.plot(range(len(y)),y,'b--',color='orange',label='Training-Error')
    ax1.scatter(range(len(x)),x,marker='^',color='orange',s=20)
    ax2.scatter(range(len(y)),y,marker='*',color='red',s=20)
    ax1.set_xlabel('epoch',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax2.set_ylabel('Error',fontsize=18)
    ax1.set_xticks([])
    ax2.set_xticks([])
    fig.legend()   
    plt.savefig('./autodl-tmp/pic-{}.png'.format( 1))
    plt.show()    