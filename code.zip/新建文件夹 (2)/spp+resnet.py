# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 20:35:23 2024

@author: lenovo
"""
"""
Created on Mon May 13 19:21:09 2024

@author: lenovo
"""
from torch import nn
import torch
import torch.nn.functional as F
import torch
import torch.nn as nn
print(torch.cuda.device_count())
print(torch.__version__)
class CBL(nn.Module):
    def __init__(self,in_channels,out_channels,kernel_size,strides,padding,inplace=True):
        super(CBL,self).__init__()
        self.conv=nn.Sequential(nn.Conv2d(in_channels, out_channels, kernel_size,strides,padding,bias=False),
        nn.BatchNorm2d(out_channels),nn.LeakyReLU(0.1,inplace=inplace))
    def forward(self,x):
        return self.conv(x)
    
class ResUint(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size = 3, strides = 1, padding = 1):
        super(ResUint,self).__init__()
        self.conv_feature=nn.Sequential(CBL(in_channels, out_channels, kernel_size, strides, padding),
            CBL(out_channels, out_channels, kernel_size, strides, padding))
        
        self.conv_redisual=nn.Conv2d(in_channels, out_channels, 1,1,0)
    def forward(self,x):
        x_redisual=self.conv_redisual(x)
        x=self.conv_feature(x)
        x=torch.add(x,x_redisual)
        return x
class ResX(nn.Module):
    def __init__(self,in_channels, out_channels_1, kernal_size_1, stride_1, padding_1, out_channels_2, kernal_size_2, stride_2, padding_2):
        super(ResX,self).__init__()
        self.conv=nn.Sequential(CBL(in_channels, out_channels_1, kernal_size_1, stride_1, padding_1),ResUint(out_channels_1, out_channels_2, kernal_size_2, stride_2, padding_2))
    def forward(self,x):
        return self.conv(x)

####SPP网络模型
class SPP(nn.Module):
    def __init__(self,input_size):
        super(SPP, self).__init__()
        self.conv1=nn.Conv2d(input_size, input_size, 3)
        self.conv2=nn.Conv2d(input_size, input_size, 3)
        self.conv3=nn.Conv2d(input_size, input_size, 3)
        self.pool1 = nn.MaxPool2d(kernel_size=5,stride=1,padding=5 // 2)
        self.pool2 = nn.MaxPool2d(kernel_size=7, stride=1, padding=7 // 2)
        self.pool3 = nn.MaxPool2d(kernel_size=13, stride=1, padding=13 // 2)
    def forward(self,x):
        x1 = self.pool1(x)
        x2 = self.pool2(x)
        x3 = self.pool3(x)
        return torch.cat([x,x1,x2,x3],dim=1)


#####自己设计的整体网络模型
class first1(nn.Module):
    def __init__(self,out_size):
        super(first1,self).__init__()
        self.spp=SPP(out_size)

        
        self.re4=ResUint(12,3,3,1,1)   
        self.linear=nn.Linear(120000, 60)
        self.linear1=nn.Linear(60, 2)
        self.linear2=nn.Linear(16, 2)
    def forward(self,x):    
        x=self.spp(x)
    
        x=self.re4(x)
        x=x.reshape(x.shape[0],-1)
        x=self.linear(x)
        x=torch.sigmoid(x)
        x=self.linear1(x)
        x= torch.softmax(x,dim=1)
        return x


import os 
import cv2
import torch
from PIL import Image
from torch.utils.data import DataLoader,Dataset,random_split
from torchvision import transforms
import numpy as np
###########设置自己的数据库
class yolovdataset(Dataset):
    def __init__(self,img_path,transforms):
        self.img_path=img_path
        self.filenames=os.listdir(img_path)
        self.transforms=transforms    
    def __len__(self):
        return len(self.filenames)
    def __getitem__(self,idx):
        img=cv2.imread(os.path.join(self.img_path,self.filenames[idx]))
        img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        img=Image.fromarray(img).convert('RGB')
        img=self.transforms(img)
        if self.filenames[idx][0]=='1':####如果图片文件名的第一个为“1”，则为正常数据。该操作依据数据的特点而来。
            label=[1.0,0.0]
        else:####如果图片文件名的第一个不为“1”，则为异常数据
            label=[0.0,1.0]
        label=torch.tensor(label) #####转化为tensor类型
        return img,label
################这个函数可以将数据集变为训练集和测试集
def create_dataloader(img_path,train_proportion,test_porportion, batch_size):
    ######数据集预处理
    transform=transforms.Compose([transforms.Resize((200,200)),transforms.ToTensor()])
    #生成整体数据集
    dataset=yolovdataset(img_path,transform)
    #数据集的数据个数
    dataset_size=len(dataset)
    #自己想要设置的训练集数据个数
    train_size=int(dataset_size*train_proportion)
    test_size=dataset_size-train_size
    ###随机划分数据集和测试集
    train_dataset,test_dataset=random_split(dataset, [train_size,test_size])
    #生成测试集
    train_loader=DataLoader(train_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    #生成测试集
    test_loader=DataLoader(test_dataset,batch_size=batch_size,shuffle=True,num_workers=0)
    return train_loader,test_loader


if __name__ == '__main__':
    #调用函数生成训练集与测试集，第一个参数为数据文件
    train_dataloader,test_dataloader=create_dataloader(r"C:\Users\lenovo\Desktop\end",0.6,0.4,20)
    test_len=len(test_dataloader)
    mymodule = first1(3)
    mymodule.to('cuda')
    loss =torch.nn.MSELoss().to('cuda')
    learnstep = 0.001
    optim = torch.optim.SGD(mymodule.parameters(),lr=learnstep,weight_decay=0.0005)
    epoch = 40
    x=[]#####保存准确度
    y=[]#####保存损失
    train_step = 0 #每轮训练的次数
    mymodule.train()#模型在训练状态

    for i in range(epoch):
        print("第{}轮训练".format(i+1))
        total_loss=0
        train_step = 0 
        for data in train_dataloader:
            imgs,targets = data
            imgs=imgs.view(-1,3,200,200)/255
            imgs=imgs.to('cuda')
            targets=targets.to('cuda')          
            outputs = mymodule(imgs)
            result_loss = loss(outputs,targets)
            total_loss+=result_loss
            optim.zero_grad()
            result_loss.backward()
            optim.step()
            train_step +=1
            if ( train_step%30==0):
                print(train_step)
           
        print("损失",total_loss/train_step)
        y.append(total_loss/train_step)
        # 在测试集上面的效果
        mymodule.eval() #在验证状态
        test_total_loss = 0
        right_number = 0
        acc_num = torch.zeros((1, 2))
        target_num = torch.zeros((1, 2)) 
        predict_num = torch.zeros((1,2))
        with torch.no_grad(): # 验证的部分，不是训练所以不要带入梯度
            for test_data  in test_dataloader:
                imgs,label = test_data
                imgs=imgs.view(-1,3,200,200)/255
                imgs=imgs.to('cuda')
                label=label.to('cuda')
                outputs_ = mymodule(imgs)
                test_result_loss=loss(outputs_,label)
                right_number += (outputs_.argmax(1)==label.argmax(1)).sum()
                _, predicted_ = outputs_.max(1)
                _, label_ = label.max(1)
                pre_mask = torch.zeros(outputs_.size()).scatter_(1, predicted_.cpu().view(-1, 1), 1.)
                predict_num += pre_mask.sum(0)  # 得到数据中每类的预测量
                tar_mask = torch.zeros(outputs_.size()).scatter_(1, label_.cpu().view(-1, 1), 1.)
                target_num += tar_mask.sum(0)  # 得到数据中每类的数量
                acc_mask = pre_mask * tar_mask 
                acc_num += acc_mask.sum(0) # 得到各类别分类正确的样本数量
                train_step +=1
                if ( train_step%30==0):
                    print(train_step)
            recall = acc_num / target_num
            precision = acc_num /predict_num
            F1 = 2 * recall * precision / (recall + precision)


            print(i,(right_number/(6*test_len)),precision,recall,F1)
            x.append(right_number/(6*test_len))
            
    torch.save(mymodule.state_dict(), 'model.pth')

    ########绘制训练损失图与模型准确度图
    import matplotlib.pyplot as plt
    import numpy as np
    y=torch.tensor(y.copy())
    x=torch.tensor(x.copy())
    y=y.cpu().numpy()
    x=x.cpu().numpy()
    fig=plt.figure()
    ax1=fig.subplots()
    ax2=ax1.twinx()   
    ax1.plot(range(len(x)),x,'g-',color='red',label='Testing-Accuracy')
    ax2.plot(range(len(y)),y,'b--',color='orange',label='Training-Error')
    ax1.scatter(range(len(x)),x,marker='^',color='orange',s=20)
    ax2.scatter(range(len(y)),y,marker='*',color='red',s=20)
    ax1.set_xlabel('epoch',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax1.set_ylabel('Accuracy',fontsize=18)
    ax2.set_ylabel('Error',fontsize=18)
    ax1.set_xticks([])
    ax2.set_xticks([])
    fig.legend()   
    plt.savefig('./autodl-tmp/pic-{}.png'.format( 1))
    plt.show()    